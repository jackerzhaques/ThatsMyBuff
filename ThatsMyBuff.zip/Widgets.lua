_, Core = ...
local ThatsMyBuff = Core.ThatsMyBuff
local IconDropdown = Core.IconDropdown
local MessageDispatcher = Core.MessageDispatcher

local Widgets = {}
Core.Widgets = Widgets
local ShamanWidget = {}
ShamanWidget.EventName = "ShamanTotemUpdate"
Widgets.ShamanWidget = ShamanWidget



--[[
    TODO

    Add a display for the actual shaman totems selected
    Maybe a smaller icon above the totem dropdown, and make it glow if it doesn't match
]]
function ShamanWidget:DropdownOptionClicked(buttonWidget)
    local payload = {name=self.shamanName, totemType=self.totemType, totemName=buttonWidget.iconName}
    MessageDispatcher:SendMessage(ShamanWidget.EventName, payload)
end

function ShamanWidget:Create(name, parentWidget, relativeWidget)
    local shaman = {}
    shaman.name = name
    local playerLabel = parentWidget:CreateFontString(nil, "OVERLAY", "GameFontNormalMed1")
    playerLabel:SetPoint("TOPLEFT", relativeWidget, "BOTTOMLEFT", 0, -30)
    playerLabel:SetText(name)
    shaman.titleWidget = playerLabel

    -- EARTH
    local earthDropdown = IconDropdown:Create(nil, parentWidget, 60, 60, self.DropdownOptionClicked)
    earthDropdown.shamanName = name
    earthDropdown.totemType = "earth"
    earthDropdown:SetSize(30,30)
    earthDropdown:SetPoint("LEFT", playerLabel, "LEFT", 90, 0)
    local earthTotems = TotemTableEarth
    for totemIdx = 1,#earthTotems do
        local totem = earthTotems[totemIdx]
        earthDropdown:AddOption(totem["icon"], totem["name"])
    end
    shaman.earthDropdown = earthDropdown

    -- FIRE
    local fireDropdown = IconDropdown:Create(nil, parentWidget, 60, 60, self.DropdownOptionClicked)
    fireDropdown.shamanName = name
    fireDropdown.totemType = "fire"
    fireDropdown:SetSize(30,30)
    fireDropdown:SetPoint("LEFT", earthDropdown, "RIGHT", 30, 0)
    local fireTotems = TotemTableFire
    for totemIdx = 1,#fireTotems do
        local totem = fireTotems[totemIdx]
        fireDropdown:AddOption(totem["icon"], totem["name"])
    end
    shaman.fireDropdown = fireDropdown

    -- WATER
    local waterDropdown = IconDropdown:Create(nil, parentWidget, 60, 60, self.DropdownOptionClicked)
    waterDropdown.shamanName = name
    waterDropdown.totemType = "water"
    waterDropdown:SetSize(30,30)
    waterDropdown:SetPoint("LEFT", fireDropdown, "RIGHT", 30, 0)
    local waterTotems = TotemTableWater
    for totemIdx = 1,#waterTotems do
        local totem = waterTotems[totemIdx]
        waterDropdown:AddOption(totem["icon"], totem["name"])
    end
    shaman.waterDropdown = waterDropdown

    -- AIR
    local airDropdown = IconDropdown:Create(nil, parentWidget, 60, 60, self.DropdownOptionClicked)
    airDropdown.shamanName = name
    airDropdown.totemType = "air"
    airDropdown:SetSize(30,30)
    airDropdown:SetPoint("LEFT", waterDropdown, "RIGHT", 30, 0)
    local airTotems = TotemTableAir
    for totemIdx = 1,#airTotems do
        local totem = airTotems[totemIdx]
        airDropdown:AddOption(totem["icon"], totem["name"])
    end
    shaman.airDropdown = airDropdown

    return shaman
end