------------------------
-- Shared Buffs
------------------------
-- Using tables to emulate enums, not sure if there is a better way to do this
ArmorFlat = {0}   -- Devotion, Stoneskin
StrengthAndAgility = {0} -- Horn of Winter, Strength of Earth
Spellpower = {0} -- Flametongue, Wrath Totem, Demo Lock
ManaPer5 = {0} -- Wisdom, Manaspring
MeleeHaste = {0} -- Windfury, Frost DK
FrostResistance = {0} -- Frost Aura, Frost Resist Totem
FireResistance = {0} -- Fire Resist Aura, Fire Resist Totem
NatureResistance = {0} --Hunter Aspect, Nature Resist Totem



-- StrengthAndAgility = {{Shaman,Enhancement},DeathKnight}
-- GiftOfTheWild = {Druid}
-- BlessingOfKings = {Paladin}
-- AttackPowerStatic = {Paladin,Warrior}   -- Might, shout
-- AttackPower10Percent = {{DeathKnight,Blood},{Hunter,Marksmanship},{Shaman,Enhancement}}
-- PhysicalCrit5Percent = {{Druid,FeralTank}, {Druid,FeralDps}, {Warrior,Fury}}
-- ManaPer5 = {{Shaman,Restoration},{Paladin,Holy},Shaman,Paladin}     -- wisdom, mana spring
-- BlessingOfSanctury = {{Paladin,Protection}}